export const SANDBOX_TIMEOUT = 60_000 * 10 * 3; // 30 minutes in MS
