"use client";

const ErrorPage = () => {
  return ( 
    <div>
      Global error
    </div>
  );
};
 
export default ErrorPage;
