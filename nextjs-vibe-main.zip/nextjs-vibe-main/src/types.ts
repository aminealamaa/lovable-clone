export type TreeItem = string | [string, ...TreeItem[]];
